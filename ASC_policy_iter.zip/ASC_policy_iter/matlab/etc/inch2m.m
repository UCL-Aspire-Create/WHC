function m = inch2m(inch)
% converts an n-dimentional array from inches to meters
m = inch*0.0254;

end

